package com.net;


public class DataSorter {

	public String sort(String input) {
		return null;
	}

}
