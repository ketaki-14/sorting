package com.net;


public class DataSorter 
{

	public String sort(String input) 
	{
		String[] ip = input.split(" ");
		Map<String, Float> mp = new HashMap<String, Float>();
		
		for(String s : ip)                        
		{
    		String[] entry = ip.split("=");                   
    		map.put(entry[0], entry[1];          
		}

		sortMapByValues(mp);
	
		return null;

	}

	public void sortMapByValues(Map<String, Float> mp) 
	{
        
        Set<Entry<String,Float>> mapEntries = mp.entrySet();
        
        List<Entry<String,Float>> aList = new LinkedList<Entry<String,Float>>(mapEntries);

        Collections.sort(aList, new Comparator<Entry<String,Float>>() 
        {

            @Override
            public int compare(Entry<String, Float> ele1,Entry<String, Float> ele2) 
            {        
                return ele1.getValue().compareTo(ele2.getValue());
            }
        });
        
        Map<String, Float> mp1 = new LinkedHashMap<String, Float>();
     
        for(Entry<String, Float> entry: aList) 
        {
            mp1.put(entry.getKey(), entry.getValue());
        }
        
        for(Entry<String, Float> entry : mp1.entrySet()) 
        {
            String s= entry.getKey() + "=" + entry.getValue() + ";";
        }

        System.out.println(s.substring(0,s.length()-1);
        
    }

}
